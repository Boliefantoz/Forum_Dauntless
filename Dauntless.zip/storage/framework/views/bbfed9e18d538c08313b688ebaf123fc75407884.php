<?php $__env->startSection('category'); ?>
    <div class="col-md-3 " >
    <div class="dp">
    <img src="https://i.redd.it/2f1u5ti5l5211.png" class="img-rounded" alt="Foto Profiel">
    </div>
        <h3 class="text-success">
           Gebruikersnaam: <?php echo e($user->name); ?>

        </h3>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="well-lg border-0 bg-info">
    
    <h3><?php echo e($user->name); ?>'s laatste Threads</h3>

    <?php $__empty_1 = true; $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <h5><?php echo e($thread->subject); ?></h5>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h5>Nog geen Threads (Gemaakt)</h5>

    <?php endif; ?>
    <br>
    <hr>

    <h3><?php echo e($user->name); ?>'s Laatste Reactie</h3>

    <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <h5><?php echo e($user->name); ?> Reageert op <a href="<?php echo e(route('thread.show',$comment->commentable->id)); ?>"><?php echo e($comment->commentable->subject); ?></a>  <?php echo e($comment->created_at->diffForHumans()); ?></h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h5>Geen Reacties</h5>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<style>
    body{
        background-image: url("https://www.pcgamesn.com/wp-content/uploads/2018/08/Dauntless-Behemoths-Koshai.png");
        background-repeat: no-repeat;
        background-size: cover;
    }
</style>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>