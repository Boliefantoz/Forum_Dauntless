<div class="col-md-3">
    
    <form method="get" action="/thread/search">

    </form>
    

    <a class="btn btn-info form-control"  href="<?php echo e(route('thread.create')); ?>">Maak Thread</a> <br><br>
    <h4>De Categorieen</h4>
    <ul class="list-group">
        <a href="<?php echo e(route('thread.index')); ?>" class="list-group-item active">
            <span class="badge"></span>
            Alle Categorieen
        </a>
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('thread.index',['tags'=>$tag->id])); ?>" class="list-group-item list-group-item-info">
            <span class="badge"></span>
            <?php echo e($tag->name); ?>

    </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
            
            
        
        
            
            
        
    </ul>
</div>