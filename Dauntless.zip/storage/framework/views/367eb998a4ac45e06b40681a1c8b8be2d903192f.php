<div class="list-group">
    <?php $__empty_1 = true; $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        
            
            
                
                
            
        


        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title"><a href="<?php echo e(route('thread.show',$thread->id)); ?>"> <?php echo e($thread->subject); ?></a></h3>
            </div>
            <div class="panel-body panel-info">
                <p><?php echo e(str_limit($thread->thread,100)); ?>

                    <br>
                    Geplaatst door <a href="<?php echo e(route('user_profile',$thread->user->name)); ?>"> <?php echo e($thread->user->name); ?></a> <?php echo e($thread->created_at->diffForHumans()); ?>

                </p>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3 class="font-weight-bold">Er bestaan momenteel geen threads/onderwerpen</h3>
       <img class="img-rounded img-responsive" src="https://assets.vg247.com/current//2019/05/dauntless-screenshot-quillshot.jpg" width="500">
    <?php endif; ?>
</div>