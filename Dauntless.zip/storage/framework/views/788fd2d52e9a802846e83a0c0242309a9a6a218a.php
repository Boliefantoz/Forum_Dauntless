<?php if(session('message')): ?>
    <div class="alert alert-info">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>