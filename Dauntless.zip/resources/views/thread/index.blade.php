@extends('layouts.front')

@section('heading')

@endsection

@section('content')

@include('thread.partials.thread-list')

@endsection